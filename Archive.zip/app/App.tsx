import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from "react";
import { Platform, StyleSheet, Text, View } from 'react-native';

const BASE =
  process.env.EXPO_PUBLIC_API_URL ??
  (Platform.OS === "android" ? "http://10.0.2.2:4000" : "http://localhost:4000");

export default function App() {
  const [status, setStatus] = useState("Checking API…");
  useEffect(() => {
    fetch(`${BASE}/api/health`).then(r => r.json())
      .then(() => setStatus("API: OK"))
      .catch(() => setStatus("API: unreachable"));
  }, []);

  return (
    <View style={styles.container}>
      <Text style={{ fontSize: 24, fontWeight: "700" }}>Hello World!</Text>
      <Text>{status}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

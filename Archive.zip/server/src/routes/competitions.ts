import { Router } from "express";
import { query } from "../db";

const router = Router();

router.get("/", async (_req, res, next) => {
    try {
        const rows = await query<{
            id: string; title: string;
            venue_name: string | null;
            starts_at: string | null; ends_at: string | null;
        }>(`SELECT *
            FROM competitions
            WHERE is_public = true
            ORDER BY starts_at NULLS LAST, created_at DESC`);
        res.json(rows);
    } catch (e) { next(e); }
});

export default router;

-- First Iteration of the Database Schema

create extension if not exists "uuid-ossp";

create table if not exists users (
    id uuid primary key default gen_random_uuid(),
    display_name text not null,
    email text unique,
    created_at timestamptz default now()
);

create table if not exists venues (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  latitude double precision not null,
  longitude double precision not null,
  created_at timestamptz default now()
);
-- Will help filter venues near me if I decide to do that later on
create index if not exists idx_venues_latlon on venues (latitude, longitude); 

create table if not exists competitions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  is_public boolean not null default true,
  venue_id uuid references venues(id) on delete set null,
  starts_at timestamptz,
  ends_at   timestamptz,
  show_grades boolean not null default false,
  scoring_mode text not null default 'TOPS_ATTEMPTS',
  rules text[] not null default '{}',
  created_by uuid references users(id) on delete set null,
  created_at timestamptz default now()
);
